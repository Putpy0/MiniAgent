"""Executor module for running shell commands and file operations safely.

This module provides abstract base classes and concrete implementations
for executing commands in a sandboxed environment with proper safety checks.
"""

from miniagent.executor.base import Executor, ExecutionResult
from miniagent.executor.subprocess_executor import SubprocessExecutor
from miniagent.executor.docker_executor import DockerExecutor, is_docker_available, create_executor
from miniagent.executor.permission import PermissionManager, CommandSafety, CommandPattern, CommandSafety, PermissionCheckResult

__all__ = [
    "Executor",
    "ExecutionResult",
    "SubprocessExecutor",
    "DockerExecutor",
    "is_docker_available",
    "create_executor",
    "PermissionManager",
    "CommandSafety",
    "CommandPattern",
    "PermissionCheckResult",
]