"""Subprocess-based executor for running shell commands safely.

This module provides the default Executor implementation using Python's subprocess
module, with comprehensive safety features including path validation, command filtering,
timeout enforcement, and audit logging.
"""

import os
import shlex
import subprocess
import logging
from datetime import datetime
from pathlib import Path
from typing import Callable, Optional, Union

from miniagent.executor.base import Executor, ExecutionResult
from miniagent.executor.permission import PermissionManager, CommandSafety


class SubprocessExecutor(Executor):
    """Execute commands using Python subprocess with safety controls.

    This executor runs commands in a restricted environment with:
    - Path traversal prevention (all operations confined to workspace)
    - Command safety classification (safe/dangerous/blocked)
    - User confirmation for dangerous commands
    - Timeout enforcement
    - Comprehensive audit logging

    Attributes:
        permission_manager: Manager for command safety checks.
        logger: Logger for audit trails.
        auto_confirm_dangerous: If True, skip confirmation for dangerous commands.
    """

    def __init__(
        self,
        workspace_root: str,
        timeout: int = 30,
        permission_manager: Optional[PermissionManager] = None,
        auto_confirm_dangerous: bool = False,
        log_file: Optional[str] = None,
        confirmation_callback: Optional[Callable[[str, str], bool]] = None,
    ):
        """Initialize the subprocess executor.

        Args:
            workspace_root: Root directory for all file operations.
            timeout: Default timeout in seconds for command execution.
            permission_manager: Custom permission manager. If None, uses defaults.
            auto_confirm_dangerous: If True, execute dangerous commands without prompting.
                Use with extreme caution!
            log_file: Path to log file for audit trail. If None, logs to standard logger.
            confirmation_callback: Callable invoked as callback(command, prompt) -> bool
                whenever a command requires user confirmation. This decouples
                confirmation from blocking stdin `input()`, so callers running
                in non-interactive contexts (CLI automation, a pipeline stage,
                a web backend, tests) can supply their own confirmation source
                (a queued UI prompt, a policy check, a canned test response,
                etc). If None, defaults to a blocking terminal prompt via
                `input()` — suitable only for direct interactive CLI use.
        """
        super().__init__(workspace_root, timeout)

        self.permission_manager = permission_manager or PermissionManager()
        self.auto_confirm_dangerous = auto_confirm_dangerous
        self.confirmation_callback = confirmation_callback or self._default_confirmation_callback

        # Setup logging
        self.logger = logging.getLogger("miniagent.executor.subprocess")
        self.logger.setLevel(logging.INFO)

        if log_file:
            # Ensure log directory exists
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)

            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(
                logging.Formatter(
                    "%(asctime)s - %(levelname)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S",
                )
            )
            self.logger.addHandler(file_handler)

        # Validate workspace exists
        workspace_path = Path(workspace_root)
        if not workspace_path.exists():
            workspace_path.mkdir(parents=True, exist_ok=True)
            self.logger.info(f"Created workspace directory: {workspace_root}")

    def _log_execution(self, result: ExecutionResult) -> None:
        """Log execution details for audit trail.

        Args:
            result: The execution result to log.
        """
        log_entry = {
            "timestamp": result.timestamp.isoformat(),
            "command": result.command,
            "cwd": result.cwd,
            "success": result.success,
            "exit_code": result.exit_code,
            "duration_ms": result.duration_ms,
            "stdout_length": len(result.stdout),
            "stderr_length": len(result.stderr),
        }

        if result.success:
            self.logger.info(f"EXEC: {log_entry}")
        else:
            self.logger.warning(f"EXEC FAILED: {log_entry} - Error: {result.error_message}")

    def _prepare_command(
        self, command: Union[str, list[str]], shell: bool
    ) -> Union[str, list[str]]:
        """Prepare command for execution based on shell mode.

        Args:
            command: Command string or list of arguments.
            shell: Whether to run through shell.

        Returns:
            Prepared command in appropriate format.

        Raises:
            ValueError: If command is empty or invalid.
        """
        if isinstance(command, list):
            if shell:
                return " ".join(shlex.quote(arg) for arg in command)
            return command

        if not command.strip():
            raise ValueError("Empty command")

        if shell:
            return command

        # Parse shell command into argument list for safety
        try:
            return shlex.split(command)
        except ValueError as e:
            raise ValueError(f"Invalid command syntax: {e}")

    def _check_permission(self, command: str) -> tuple[bool, str]:
        """Check if command has required permissions.

        Args:
            command: Command string to check.

        Returns:
            Tuple of (allowed, reason). If allowed is False, reason explains why.
        """
        result = self.permission_manager.check_command(command)

        if result.blocked:
            return False, f"Command blocked: {result.description}"

        if result.requires_confirmation and not self.auto_confirm_dangerous:
            return False, f"Confirmation required: {result.description}"

        return True, "OK"

    @staticmethod
    def _default_confirmation_callback(command: str, prompt: str) -> bool:
        """Default confirmation callback: blocking terminal prompt via input().

        Only appropriate for direct interactive CLI use. Any non-interactive
        caller (pipeline stage, agentic loop, web request, test harness)
        MUST supply its own `confirmation_callback` to SubprocessExecutor
        instead of relying on this, or execution will hang waiting on stdin.

        Args:
            command: Command requiring confirmation (unused here, but part
                of the callback signature for callers that want it).
            prompt: Pre-formatted prompt text to display to the user.

        Returns:
            True if user confirmed ("y"/"yes"), False otherwise.
        """
        print(prompt)
        try:
            response = input().strip().lower()
            return response in ("y", "yes")
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return False

    def request_confirmation(self, command: str) -> bool:
        """Request confirmation for a command via the configured callback.

        This never blocks on stdin directly — it delegates to
        `self.confirmation_callback`, which defaults to a blocking terminal
        prompt but can be replaced with any non-blocking or programmatic
        confirmation source (see `__init__`).

        Args:
            command: Command requiring confirmation.

        Returns:
            True if confirmed, False otherwise.
        """
        prompt = self.permission_manager.get_confirmation_prompt(command)
        try:
            return bool(self.confirmation_callback(command, prompt))
        except Exception as e:
            # A misbehaving callback must never crash execution or silently
            # approve a dangerous command — fail closed.
            self.logger.warning(f"Confirmation callback raised {type(e).__name__}: {e}")
            return False

    def run_command(
        self,
        command: Union[str, list[str]],
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
        shell: bool = False,
    ) -> ExecutionResult:
        """Execute a shell command.

        Args:
            command: Command to execute. Can be string or list of arguments.
            cwd: Working directory. Must be within workspace_root.
            timeout: Timeout in seconds. Uses default if None.
            shell: If True, run through shell. Default False for safety.

        Returns:
            ExecutionResult with command output and metadata.

        Raises:
            PermissionError: If command requires confirmation and user denied.
            ValueError: If command is invalid or cwd is outside workspace.
            TimeoutError: If command exceeds timeout.
        """
        start_time = datetime.now()

        # Normalize command to string for permission checks
        if isinstance(command, list):
            command_str = " ".join(command)
        else:
            command_str = command

        # Check permissions
        allowed, reason = self._check_permission(command_str)
        if not allowed:
            if "Confirmation required" in reason:
                if not self.request_confirmation(command_str):
                    return ExecutionResult.failure_result(
                        error_message="User denied confirmation",
                        command=command_str,
                        cwd=cwd or self.workspace_root,
                    )
            else:
                return ExecutionResult.failure_result(
                    error_message=reason,
                    command=command_str,
                    cwd=cwd or self.workspace_root,
                )

        # Resolve working directory
        if cwd is None:
            exec_cwd = self.workspace_root
        else:
            try:
                exec_cwd = self.validate_path(cwd)
            except PermissionError as e:
                return ExecutionResult.failure_result(
                    error_message=str(e),
                    command=command_str,
                    cwd=cwd,
                )

        # Ensure cwd exists
        if not os.path.isdir(exec_cwd):
            return ExecutionResult.failure_result(
                error_message=f"Working directory does not exist: {exec_cwd}",
                command=command_str,
                cwd=exec_cwd,
            )

        # Prepare command
        try:
            prepared_command = self._prepare_command(command, shell)
        except ValueError as e:
            return ExecutionResult.failure_result(
                error_message=str(e),
                command=command_str,
                cwd=exec_cwd,
            )

        # Execute command
        effective_timeout = timeout or self.timeout
        try:
            process = subprocess.run(
                prepared_command,
                cwd=exec_cwd,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
                shell=shell,
                env=os.environ.copy(),
            )

            duration_ms = (datetime.now() - start_time).total_seconds() * 1000

            result = ExecutionResult(
                success=process.returncode == 0,
                stdout=process.stdout,
                stderr=process.stderr,
                exit_code=process.returncode,
                duration_ms=duration_ms,
                timestamp=datetime.now(),
                command=command_str,
                cwd=exec_cwd,
            )

            self._log_execution(result)
            return result

        except subprocess.TimeoutExpired as e:
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            result = ExecutionResult.failure_result(
                error_message=f"Command timed out after {effective_timeout}s",
                command=command_str,
                cwd=exec_cwd,
                duration_ms=duration_ms,
                stderr=e.stderr if isinstance(e.stderr, str) else str(e.stderr),
                exit_code=-9,
            )
            self._log_execution(result)
            return result

        except FileNotFoundError as e:
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            result = ExecutionResult.failure_result(
                error_message=f"Command not found: {prepared_command[0] if isinstance(prepared_command, list) else command_str}",
                command=command_str,
                cwd=exec_cwd,
                duration_ms=duration_ms,
                stderr=str(e),
                exit_code=-1,
            )
            self._log_execution(result)
            return result

        except Exception as e:
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            result = ExecutionResult.failure_result(
                error_message=f"Execution failed: {str(e)}",
                command=command_str,
                cwd=exec_cwd,
                duration_ms=duration_ms,
                stderr=str(e),
                exit_code=-1,
            )
            self._log_execution(result)
            return result

    def read_file(self, path: str) -> str:
        """Read contents of a file.

        Args:
            path: Path to file (absolute or relative to workspace).

        Returns:
            File contents as string.

        Raises:
            FileNotFoundError: If file doesn't exist.
            PermissionError: If path is outside workspace.
            IsADirectoryError: If path is a directory.
        """
        validated_path = self.validate_path(path)

        if not os.path.exists(validated_path):
            raise FileNotFoundError(f"File not found: {path}")

        if os.path.isdir(validated_path):
            raise IsADirectoryError(f"Path is a directory: {path}")

        with open(validated_path, "r", encoding="utf-8") as f:
            return f.read()

    def write_file(self, path: str, content: str, create_dirs: bool = True) -> None:
        """Write content to a file.

        Args:
            path: Path to file (absolute or relative to workspace).
            content: Content to write.
            create_dirs: If True, create parent directories as needed.

        Raises:
            PermissionError: If path is outside workspace.
            OSError: If unable to write file.
        """
        validated_path = self.validate_path(path)

        if create_dirs:
            parent = Path(validated_path).parent
            parent.mkdir(parents=True, exist_ok=True)

        with open(validated_path, "w", encoding="utf-8") as f:
            f.write(content)

        self.logger.info(f"WRITE: {path} ({len(content)} bytes)")

    def file_exists(self, path: str) -> bool:
        """Check if a file exists.

        Args:
            path: Path to check.

        Returns:
            True if file exists, False otherwise.

        Raises:
            PermissionError: If path is outside workspace.
        """
        try:
            validated_path = self.validate_path(path)
            return os.path.isfile(validated_path)
        except PermissionError:
            return False

    def list_directory(self, path: str) -> list[str]:
        """List contents of a directory.

        Args:
            path: Path to directory.

        Returns:
            List of filenames in directory.

        Raises:
            NotADirectoryError: If path is not a directory.
            PermissionError: If path is outside workspace.
        """
        validated_path = self.validate_path(path)

        if not os.path.isdir(validated_path):
            raise NotADirectoryError(f"Path is not a directory: {path}")

        return os.listdir(validated_path)

    def delete_file(self, path: str) -> bool:
        """Delete a file.

        Args:
            path: Path to file to delete.

        Returns:
            True if file was deleted, False if it didn't exist.

        Raises:
            PermissionError: If path is outside workspace or is a directory.
        """
        validated_path = self.validate_path(path)

        if os.path.isdir(validated_path):
            raise PermissionError(f"Cannot delete directory with this method: {path}")

        if not os.path.exists(validated_path):
            return False

        os.remove(validated_path)
        self.logger.info(f"DELETE: {path}")
        return True

    def append_file(self, path: str, content: str) -> None:
        """Append content to a file.

        Args:
            path: Path to file.
            content: Content to append.

        Raises:
            PermissionError: If path is outside workspace.
            OSError: If unable to write to file.
        """
        validated_path = self.validate_path(path)

        with open(validated_path, "a", encoding="utf-8") as f:
            f.write(content)

        self.logger.info(f"APPEND: {path} ({len(content)} bytes)")
