"""Permission management for command safety.

This module provides functionality to classify commands as safe or dangerous,
and to prompt users for confirmation before executing potentially harmful operations.
"""

import re
from dataclasses import dataclass, field
from typing import Optional
from enum import Enum


class CommandSafety(Enum):
    """Classification of command safety level."""

    SAFE = "safe"
    QUESTIONABLE = "questionable"
    DANGEROUS = "dangerous"
    BLOCKED = "blocked"


@dataclass
class CommandPattern:
    """Pattern for matching commands.

    Attributes:
        pattern: Regex pattern to match the command.
        safety: Safety classification of this pattern.
        description: Human-readable description of why this is dangerous/safe.
        requires_confirmation: Whether user confirmation is required.
    """

    pattern: str
    safety: CommandSafety
    description: str = ""
    requires_confirmation: bool = False
    # Lazily-compiled regex, cached after first use. Avoids paying
    # re.compile() cost on every single check_command() call — this matters
    # now that compound commands are split and each sub-command is checked
    # against the full pattern list independently (see PermissionManager).
    _compiled: "Optional[re.Pattern[str]]" = field(default=None, repr=False, compare=False)

    def compiled(self) -> "Optional[re.Pattern[str]]":
        """Return the compiled regex for this pattern, compiling and caching on first use.

        Returns:
            Compiled `re.Pattern`, or None if `pattern` is not valid regex
            (invalid patterns are treated as non-matching rather than raising).
        """
        if self._compiled is None:
            try:
                self._compiled = re.compile(self.pattern, re.IGNORECASE)
            except re.error:
                # Cache a pattern that can never match, so we don't retry
                # compiling (and failing) on every single check.
                self._compiled = re.compile(r"(?!)")
        return self._compiled


# Default dangerous command patterns
DEFAULT_DANGEROUS_PATTERNS = [
    # File destruction
    CommandPattern(
        r"^rm\s+(-[rf]+\s+)?(/\s*|~/?|\.\./)",
        CommandSafety.DANGEROUS,
        "Attempting to remove files from root, home, or parent directories",
        requires_confirmation=True,
    ),
    CommandPattern(
        r"^rm\s+-rf\s+/",
        CommandSafety.BLOCKED,
        "Recursive force delete from root - extremely dangerous",
        requires_confirmation=True,
    ),
    CommandPattern(
        r"^rm\s+--no-preserve-root",
        CommandSafety.BLOCKED,
        "Disabling root protection for rm",
        requires_confirmation=True,
    ),
    # Disk operations
    CommandPattern(
        r"^(mkfs|mke2fs|fdisk|parted|dd)\s+",
        CommandSafety.DANGEROUS,
        "Disk formatting or partitioning operation",
        requires_confirmation=True,
    ),
    CommandPattern(
        r"^dd\s+.*of=/dev/",
        CommandSafety.BLOCKED,
        "Writing directly to block devices",
        requires_confirmation=True,
    ),
    # Privilege escalation
    CommandPattern(
        r"^sudo\s+",
        CommandSafety.DANGEROUS,
        "Running command with elevated privileges",
        requires_confirmation=True,
    ),
    CommandPattern(
        r"^su\s+(-\s*)?root",
        CommandSafety.DANGEROUS,
        "Switching to root user",
        requires_confirmation=True,
    ),
    # Fork bombs and resource exhaustion
    CommandPattern(
        r":\(\)\{\s*:\s*\|\s*&\s*\}\s*;",
        CommandSafety.BLOCKED,
        "Fork bomb detected",
        requires_confirmation=True,
    ),
    CommandPattern(
        r"^\{\s*:\s*\|\s:&\s*\}\s*;",
        CommandSafety.BLOCKED,
        "Fork bomb variant detected",
        requires_confirmation=True,
    ),
    # Network attacks
    CommandPattern(
        r"^(nmap|masscan)\s+",
        CommandSafety.QUESTIONABLE,
        "Network scanning tool",
        requires_confirmation=False,
    ),
    # Download and execute patterns
    CommandPattern(
        r"^(curl|wget)\s+.*\|\s*(bash|sh|zsh)",
        CommandSafety.DANGEROUS,
        "Downloading and piping directly to shell interpreter",
        requires_confirmation=True,
    ),
    CommandPattern(
        r"^(curl|wget)\s+.*-o\s*/",
        CommandSafety.QUESTIONABLE,
        "Downloading file to root directory",
        requires_confirmation=False,
    ),
    # Process manipulation
    CommandPattern(
        r"^kill\s+-9\s+",
        CommandSafety.QUESTIONABLE,
        "Force killing processes",
        requires_confirmation=False,
    ),
    CommandPattern(
        r"^pkill\s+-f\s+",
        CommandSafety.QUESTIONABLE,
        "Killing processes by pattern",
        requires_confirmation=False,
    ),
    # Environment manipulation
    CommandPattern(
        r"^export\s+(LD_PRELOAD|LD_LIBRARY_PATH)",
        CommandSafety.DANGEROUS,
        "Modifying dynamic linker paths",
        requires_confirmation=True,
    ),
    # History manipulation
    CommandPattern(
        r"^history\s+(-c|-d)",
        CommandSafety.QUESTIONABLE,
        "Clearing or deleting command history",
        requires_confirmation=False,
    ),
]

# Default safe command patterns
DEFAULT_SAFE_PATTERNS = [
    # Basic navigation and listing
    CommandPattern(r"^ls(\s+.*)?$", CommandSafety.SAFE, "List directory contents"),
    CommandPattern(r"^pwd(\s+.*)?$", CommandSafety.SAFE, "Print working directory"),
    CommandPattern(r"^cd(\s+.*)?$", CommandSafety.SAFE, "Change directory"),
    CommandPattern(r"^dir(\s+.*)?$", CommandSafety.SAFE, "List directory (Windows style)"),
    # File reading
    CommandPattern(r"^cat(\s+.*)?$", CommandSafety.SAFE, "Display file contents"),
    CommandPattern(r"^head(\s+.*)?$", CommandSafety.SAFE, "Display first lines of file"),
    CommandPattern(r"^tail(\s+.*)?$", CommandSafety.SAFE, "Display last lines of file"),
    CommandPattern(r"^less(\s+.*)?$", CommandSafety.SAFE, "View file in pager"),
    CommandPattern(r"^more(\s+.*)?$", CommandSafety.SAFE, "View file page by page"),
    # File operations (non-destructive)
    CommandPattern(r"^cp(\s+.*)?$", CommandSafety.SAFE, "Copy files"),
    CommandPattern(r"^mv(\s+.*)?$", CommandSafety.SAFE, "Move/rename files"),
    CommandPattern(r"^mkdir(\s+.*)?$", CommandSafety.SAFE, "Create directories"),
    CommandPattern(r"^touch(\s+.*)?$", CommandSafety.SAFE, "Create empty file or update timestamp"),
    # Development tools
    CommandPattern(r"^python3?\s+", CommandSafety.SAFE, "Run Python interpreter"),
    CommandPattern(r"^pip3?\s+", CommandSafety.SAFE, "Python package manager"),
    CommandPattern(r"^npm(\s+.*)?$", CommandSafety.SAFE, "Node.js package manager"),
    CommandPattern(r"^yarn(\s+.*)?$", CommandSafety.SAFE, "Yarn package manager"),
    CommandPattern(r"^node(\s+.*)?$", CommandSafety.SAFE, "Run Node.js"),
    CommandPattern(r"^cargo(\s+.*)?$", CommandSafety.SAFE, "Rust package manager"),
    CommandPattern(r"^rustc(\s+.*)?$", CommandSafety.SAFE, "Rust compiler"),
    CommandPattern(r"^go(\s+.*)?$", CommandSafety.SAFE, "Go language tool"),
    CommandPattern(r"^javac(\s+.*)?$", CommandSafety.SAFE, "Java compiler"),
    CommandPattern(r"^java(\s+.*)?$", CommandSafety.SAFE, "Run Java"),
    # Version control
    CommandPattern(r"^git(\s+.*)?$", CommandSafety.SAFE, "Git version control"),
    CommandPattern(r"^svn(\s+.*)?$", CommandSafety.SAFE, "Subversion"),
    CommandPattern(r"^hg(\s+.*)?$", CommandSafety.SAFE, "Mercurial"),
    # Text processing
    CommandPattern(r"^grep(\s+.*)?$", CommandSafety.SAFE, "Search text patterns"),
    CommandPattern(r"^sed(\s+.*)?$", CommandSafety.SAFE, "Stream editor"),
    CommandPattern(r"^awk(\s+.*)?$", CommandSafety.SAFE, "Pattern scanning and processing"),
    CommandPattern(r"^sort(\s+.*)?$", CommandSafety.SAFE, "Sort lines of text"),
    CommandPattern(r"^uniq(\s+.*)?$", CommandSafety.SAFE, "Report or filter repeated lines"),
    CommandPattern(r"^wc(\s+.*)?$", CommandSafety.SAFE, "Word, line, character count"),
    # System information
    CommandPattern(r"^echo(\s+.*)?$", CommandSafety.SAFE, "Display message"),
    CommandPattern(r"^printenv(\s+.*)?$", CommandSafety.SAFE, "Print environment variables"),
    CommandPattern(r"^env(\s+.*)?$", CommandSafety.SAFE, "Run command in modified environment"),
    CommandPattern(r"^whoami(\s+.*)?$", CommandSafety.SAFE, "Print current user"),
    CommandPattern(r"^uname(\s+.*)?$", CommandSafety.SAFE, "System information"),
    CommandPattern(r"^hostname(\s+.*)?$", CommandSafety.SAFE, "System hostname"),
    # Build tools
    CommandPattern(r"^make(\s+.*)?$", CommandSafety.SAFE, "Build automation"),
    CommandPattern(r"^cmake(\s+.*)?$", CommandSafety.SAFE, "Cross-platform build system"),
    CommandPattern(r"^meson(\s+.*)?$", CommandSafety.SAFE, "Ninja-based build system"),
    # Compression
    CommandPattern(r"^tar(\s+.*)?$", CommandSafety.SAFE, "Archive utility"),
    CommandPattern(r"^zip(\s+.*)?$", CommandSafety.SAFE, "Compress files"),
    CommandPattern(r"^unzip(\s+.*)?$", CommandSafety.SAFE, "Extract zip archives"),
    CommandPattern(r"^gzip(\s+.*)?$", CommandSafety.SAFE, "Compress files with gzip"),
    CommandPattern(r"^gunzip(\s+.*)?$", CommandSafety.SAFE, "Decompress gzip files"),
    # Safe downloads
    CommandPattern(r"^curl(\s+.*)?$", CommandSafety.SAFE, "Transfer data with URL syntax"),
    CommandPattern(r"^wget(\s+.*)?$", CommandSafety.SAFE, "Non-interactive network downloader"),
    # Docker (generally safe in controlled environments)
    CommandPattern(r"^docker(\s+.*)?$", CommandSafety.SAFE, "Docker container platform"),
    CommandPattern(r"^docker-compose(\s+.*)?$", CommandSafety.SAFE, "Docker Compose"),
    # Testing
    CommandPattern(r"^pytest(\s+.*)?$", CommandSafety.SAFE, "Python testing framework"),
    CommandPattern(r"^unittest(\s+.*)?$", CommandSafety.SAFE, "Python unittest"),
    CommandPattern(r"^jest(\s+.*)?$", CommandSafety.SAFE, "JavaScript testing framework"),
]


@dataclass
class PermissionCheckResult:
    """Result of a permission check.

    Attributes:
        safety: Safety classification of the command.
        matched_pattern: The pattern that matched (if any).
        requires_confirmation: Whether user confirmation is needed.
        description: Description of why this classification was given.
        blocked: Whether the command should be blocked entirely.
    """

    safety: CommandSafety = CommandSafety.QUESTIONABLE
    matched_pattern: Optional[str] = None
    requires_confirmation: bool = False
    description: str = "Command not matched by any known pattern"
    blocked: bool = False


class PermissionManager:
    """Manages command permissions and safety checks.

    This class evaluates commands against configurable patterns to determine
    if they are safe to run automatically, require user confirmation, or
    should be blocked entirely.

    Attributes:
        dangerous_patterns: List of dangerous command patterns.
        safe_patterns: List of safe command patterns.
        auto_confirm_safe: If True, safe commands don't require confirmation.
    """

    def __init__(
        self,
        dangerous_patterns: Optional[list[CommandPattern]] = None,
        safe_patterns: Optional[list[CommandPattern]] = None,
        auto_confirm_safe: bool = True,
    ):
        """Initialize the permission manager.

        Args:
            dangerous_patterns: Custom list of dangerous patterns. If None, uses defaults.
            safe_patterns: Custom list of safe patterns. If None, uses defaults.
            auto_confirm_safe: If True, commands classified as SAFE don't need confirmation.
        """
        self.dangerous_patterns = dangerous_patterns or DEFAULT_DANGEROUS_PATTERNS.copy()
        self.safe_patterns = safe_patterns or DEFAULT_SAFE_PATTERNS.copy()
        self.auto_confirm_safe = auto_confirm_safe

    def add_dangerous_pattern(self, pattern: CommandPattern) -> None:
        """Add a custom dangerous pattern.

        Args:
            pattern: The pattern to add.
        """
        self.dangerous_patterns.append(pattern)

    def add_safe_pattern(self, pattern: CommandPattern) -> None:
        """Add a custom safe pattern.

        Args:
            pattern: The pattern to add.
        """
        self.safe_patterns.append(pattern)

    # Shell metacharacters that separate/chain sub-commands. Any command
    # string containing one of these MUST have every resulting sub-command
    # evaluated independently — otherwise a dangerous command can "hide"
    # behind a leading safe command (e.g. "ls; rm -rf ~") and be waved
    # through by a permissive safe-pattern that ends in ".*".
    _SPLIT_PATTERN = re.compile(r";|\&\&|\|\||\||`|\$\(")

    def _split_compound_command(self, command: str) -> list[str]:
        """Split a command string into its constituent sub-commands.

        Splits on shell chaining/piping/substitution operators (;, &&, ||,
        |, backticks, $()) so each sub-command can be evaluated on its own
        merits. This prevents a dangerous command from bypassing detection
        by being appended after an unrelated safe command.

        Args:
            command: The full command string.

        Returns:
            List of trimmed sub-command strings (non-empty).
        """
        parts = self._SPLIT_PATTERN.split(command)
        return [p.strip() for p in parts if p.strip()]

    def _check_single_command(self, command: str) -> PermissionCheckResult:
        """Evaluate a single (non-compound) command against known patterns.

        Args:
            command: A single sub-command string, already isolated from any
                shell chaining operators.

        Returns:
            PermissionCheckResult with safety classification and metadata.
        """
        # First check dangerous patterns (they take precedence)
        for pattern in self.dangerous_patterns:
            if pattern.compiled().search(command):
                return PermissionCheckResult(
                    safety=pattern.safety,
                    matched_pattern=pattern.pattern,
                    requires_confirmation=pattern.requires_confirmation,
                    description=pattern.description or f"Matches dangerous pattern: {pattern.pattern}",
                    blocked=pattern.safety == CommandSafety.BLOCKED,
                )

        # Then check safe patterns
        for pattern in self.safe_patterns:
            if pattern.compiled().search(command):
                requires_confirmation = (
                    not self.auto_confirm_safe
                    and pattern.safety != CommandSafety.SAFE
                )
                return PermissionCheckResult(
                    safety=pattern.safety,
                    matched_pattern=pattern.pattern,
                    requires_confirmation=requires_confirmation,
                    description=pattern.description or f"Matches safe pattern: {pattern.pattern}",
                    blocked=False,
                )

        # Default: questionable command that needs review
        return PermissionCheckResult(
            safety=CommandSafety.QUESTIONABLE,
            matched_pattern=None,
            requires_confirmation=True,
            description="Command not recognized - manual review recommended",
            blocked=False,
        )

    def check_command(self, command: str) -> PermissionCheckResult:
        """Check if a command is safe to execute.

        This method evaluates the command against both dangerous and safe
        patterns. If the command is a compound command (contains shell
        chaining operators like ;, &&, ||, |, backticks, or $()), each
        sub-command is evaluated independently and the LEAST safe result
        wins — a single dangerous/blocked sub-command makes the whole
        command dangerous/blocked, regardless of what precedes or follows
        it. This closes the bypass where "safe_cmd; dangerous_cmd" would
        otherwise match a permissive safe pattern (e.g. "^ls(\\s+.*)?$")
        for the entire string.

        Args:
            command: The command string to evaluate.

        Returns:
            PermissionCheckResult with safety classification and metadata.
        """
        sub_commands = self._split_compound_command(command)

        # Not compound (or splitting produced nothing useful) — evaluate as-is.
        if len(sub_commands) <= 1:
            return self._check_single_command(command)

        # Compound command: evaluate every sub-command and keep the worst one.
        severity_order = {
            CommandSafety.SAFE: 0,
            CommandSafety.QUESTIONABLE: 1,
            CommandSafety.DANGEROUS: 2,
            CommandSafety.BLOCKED: 3,
        }

        worst_result = PermissionCheckResult(
            safety=CommandSafety.SAFE,
            matched_pattern=None,
            requires_confirmation=False,
            description="All sub-commands classified as safe",
            blocked=False,
        )

        for sub_command in sub_commands:
            result = self._check_single_command(sub_command)
            if severity_order[result.safety] > severity_order[worst_result.safety]:
                worst_result = result

        # A compound command is never auto-confirmed purely because each
        # individual piece looked safe in isolation — chaining itself is
        # worth a human glance the first time, unless every single piece
        # was explicitly SAFE with no confirmation required.
        if worst_result.safety == CommandSafety.SAFE and not worst_result.requires_confirmation:
            worst_result = PermissionCheckResult(
                safety=CommandSafety.SAFE,
                matched_pattern=worst_result.matched_pattern,
                requires_confirmation=not self.auto_confirm_safe,
                description=(
                    "Compound command; all sub-commands individually classified as safe: "
                    + " | ".join(sub_commands)
                ),
                blocked=False,
            )

        return worst_result

    def is_safe(self, command: str) -> bool:
        """Quick check if command is definitely safe.

        Args:
            command: The command to check.

        Returns:
            True if command is classified as SAFE, False otherwise.
        """
        result = self.check_command(command)
        return result.safety == CommandSafety.SAFE and not result.requires_confirmation

    def is_dangerous(self, command: str) -> bool:
        """Quick check if command is dangerous or blocked.

        Args:
            command: The command to check.

        Returns:
            True if command is DANGEROUS or BLOCKED, False otherwise.
        """
        result = self.check_command(command)
        return result.safety in (CommandSafety.DANGEROUS, CommandSafety.BLOCKED)

    def is_blocked(self, command: str) -> bool:
        """Check if command should be blocked entirely.

        Args:
            command: The command to check.

        Returns:
            True if command is BLOCKED, False otherwise.
        """
        result = self.check_command(command)
        return result.blocked

    def get_confirmation_prompt(self, command: str) -> str:
        """Generate a confirmation prompt for a command.

        Args:
            command: The command requiring confirmation.

        Returns:
            Formatted prompt string asking for user confirmation.
        """
        result = self.check_command(command)

        emoji = "⚠️" if result.safety == CommandSafety.DANGEROUS else "❓"
        severity = result.safety.value.upper()

        prompt_lines = [
            f"{emoji} [{severity}] Command requires confirmation:",
            f"  $ {command}",
            f"  Reason: {result.description}",
            "",
            "Proceed? [y/N]: ",
        ]

        return "\n".join(prompt_lines)

    def extract_base_command(self, command: str) -> str:
        """Extract the base command (first word) from a command string.

        Args:
            command: Full command string.

        Returns:
            Base command (first word), lowercased.
        """
        # Handle empty command
        if not command.strip():
            return ""

        # Split on whitespace and get first token
        parts = command.strip().split()
        if not parts:
            return ""

        base = parts[0]

        # Remove leading sudo/su to check actual command
        if base in ("sudo", "su"):
            if len(parts) > 1:
                base = parts[1]

        return base.lower()
