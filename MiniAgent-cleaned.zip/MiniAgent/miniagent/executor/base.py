"""Abstract base class for command and file execution.

This module defines the interface that all executor implementations must follow,
ensuring consistent behavior across different execution backends (subprocess, Docker, etc.).
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional
from datetime import datetime
import os


@dataclass
class ExecutionResult:
    """Result of a command or file operation execution.

    Attributes:
        success: Whether the execution completed successfully.
        stdout: Standard output from the command (if applicable).
        stderr: Standard error from the command (if applicable).
        exit_code: Exit code from the command (0 for success, non-zero for failure).
        duration_ms: Execution duration in milliseconds.
        error_message: Human-readable error message if execution failed.
        timestamp: When the execution was performed.
        command: The command that was executed.
        cwd: Working directory where command was executed.
    """

    success: bool
    stdout: str = ""
    stderr: str = ""
    exit_code: int = 0
    duration_ms: float = 0.0
    error_message: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    command: str = ""
    cwd: str = ""

    def __str__(self) -> str:
        """Return a human-readable summary of the execution result."""
        status = "✓ Success" if self.success else f"✗ Failed (exit {self.exit_code})"
        lines = [
            f"[{status}] {self.command}",
            f"  Duration: {self.duration_ms:.2f}ms",
            f"  Working Dir: {self.cwd}",
        ]
        if self.stdout:
            lines.append(f"  STDOUT:\n{self._indent(self.stdout)}")
        if self.stderr:
            lines.append(f"  STDERR:\n{self._indent(self.stderr)}")
        if self.error_message:
            lines.append(f"  Error: {self.error_message}")
        return "\n".join(lines)

    @staticmethod
    def _indent(text: str, spaces: int = 4) -> str:
        """Indent multi-line text for pretty printing."""
        return "\n".join(f"{' ' * spaces}{line}" for line in text.splitlines())

    @classmethod
    def success_result(
        cls,
        stdout: str,
        command: str = "",
        cwd: str = "",
        duration_ms: float = 0.0,
    ) -> "ExecutionResult":
        """Create a successful execution result.

        Args:
            stdout: Standard output from the command.
            command: The command that was executed.
            cwd: Working directory where command was executed.
            duration_ms: Execution duration in milliseconds.

        Returns:
            ExecutionResult with success=True.
        """
        return cls(
            success=True,
            stdout=stdout,
            command=command,
            cwd=cwd,
            duration_ms=duration_ms,
        )

    @classmethod
    def failure_result(
        cls,
        error_message: str,
        command: str = "",
        cwd: str = "",
        duration_ms: float = 0.0,
        stderr: str = "",
        exit_code: int = -1,
    ) -> "ExecutionResult":
        """Create a failed execution result.

        Args:
            error_message: Human-readable error message.
            command: The command that was executed.
            cwd: Working directory where command was executed.
            duration_ms: Execution duration in milliseconds.
            stderr: Standard error from the command.
            exit_code: Exit code from the command.

        Returns:
            ExecutionResult with success=False.
        """
        return cls(
            success=False,
            error_message=error_message,
            command=command,
            cwd=cwd,
            duration_ms=duration_ms,
            stderr=stderr,
            exit_code=exit_code,
        )


class Executor(ABC):
    """Abstract base class for command and file execution.

    All executor implementations must inherit from this class and implement
    the required methods for running commands and performing file operations.

    The executor is responsible for:
    - Running shell commands with proper timeout and resource limits
    - Reading and writing files within a restricted workspace
    - Ensuring safety by preventing path traversal attacks
    - Logging all executions for audit trails
    """

    def __init__(self, workspace_root: str, timeout: int = 30):
        """Initialize the executor.

        Args:
            workspace_root: Root directory for all file operations. All paths
                must be within this directory to prevent escaping.
            timeout: Default timeout in seconds for command execution.
        """
        self.workspace_root = workspace_root
        self.timeout = timeout
        # Resolved once at construction rather than on every validate_path()
        # call — realpath() touches the filesystem (symlink resolution) and
        # workspace_root doesn't change after init, so recomputing it per
        # call is pure overhead on a path that runs for every single file
        # op and command execution.
        self._workspace_real = os.path.realpath(workspace_root)

    @abstractmethod
    def run_command(
        self,
        command: str,
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
        shell: bool = False,
    ) -> ExecutionResult:
        """Execute a shell command.

        Args:
            command: The command to execute. If shell=False, this should be
                a list of arguments; if shell=True, a single string.
            cwd: Working directory for the command. Must be within workspace_root.
                If None, uses workspace_root.
            timeout: Timeout in seconds. If None, uses default timeout.
            shell: Whether to run command through shell. Default False for safety.

        Returns:
            ExecutionResult containing stdout, stderr, exit_code, and metadata.

        Raises:
            PermissionError: If command is on the dangerous list and requires approval.
            TimeoutError: If command exceeds the timeout.
            ValueError: If cwd is outside workspace_root.
        """
        pass

    @abstractmethod
    def read_file(self, path: str) -> str:
        """Read contents of a file.

        Args:
            path: Path to the file. Can be absolute or relative to workspace_root.
                Path will be validated to ensure it's within workspace_root.

        Returns:
            Contents of the file as a string.

        Raises:
            FileNotFoundError: If file does not exist.
            PermissionError: If path is outside workspace_root.
            IsADirectoryError: If path points to a directory.
        """
        pass

    @abstractmethod
    def write_file(self, path: str, content: str, create_dirs: bool = True) -> None:
        """Write content to a file.

        Args:
            path: Path to the file. Can be absolute or relative to workspace_root.
                Path will be validated to ensure it's within workspace_root.
            content: Content to write to the file.
            create_dirs: If True, create parent directories if they don't exist.

        Raises:
            PermissionError: If path is outside workspace_root.
            OSError: If unable to write to the file.
        """
        pass

    @abstractmethod
    def file_exists(self, path: str) -> bool:
        """Check if a file exists.

        Args:
            path: Path to check. Can be absolute or relative to workspace_root.

        Returns:
            True if file exists, False otherwise.

        Raises:
            PermissionError: If path is outside workspace_root.
        """
        pass

    @abstractmethod
    def list_directory(self, path: str) -> list[str]:
        """List contents of a directory.

        Args:
            path: Path to the directory. Can be absolute or relative to workspace_root.

        Returns:
            List of filenames in the directory.

        Raises:
            PermissionError: If path is outside workspace_root.
            NotADirectoryError: If path is not a directory.
        """
        pass

    def validate_path(self, path: str) -> str:
        """Validate and resolve a path to ensure it's within workspace_root.

        This method prevents path traversal attacks by ensuring the resolved
        absolute path starts with the workspace_root.

        Args:
            path: Path to validate. Can be absolute or relative.

        Returns:
            Resolved absolute path.

        Raises:
            PermissionError: If resolved path is outside workspace_root.
        """
        # Resolve to absolute path
        if os.path.isabs(path):
            resolved = os.path.realpath(path)
        else:
            resolved = os.path.realpath(os.path.join(self.workspace_root, path))

        # Ensure path is within workspace_root
        workspace_real = self._workspace_real
        if not resolved.startswith(workspace_real + os.sep) and resolved != workspace_real:
            raise PermissionError(
                f"Path traversal detected: '{path}' resolves to '{resolved}' "
                f"which is outside workspace '{workspace_real}'"
            )

        return resolved

    def get_workspace_root(self) -> str:
        """Get the workspace root directory.

        Returns:
            Absolute path to workspace root.
        """
        return self._workspace_real
