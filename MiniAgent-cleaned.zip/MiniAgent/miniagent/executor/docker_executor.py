"""Optional Docker-based executor for enhanced isolation.

This module provides an alternative Executor implementation that runs commands
inside Docker containers for better isolation and security. It automatically
detects if Docker is available and falls back gracefully if not.
"""

import os
import subprocess
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional, Union

from miniagent.executor.base import Executor, ExecutionResult
from miniagent.executor.permission import PermissionManager


class DockerExecutor(Executor):
    """Execute commands inside Docker containers for isolation.

    This executor runs all commands inside ephemeral Docker containers,
    providing:
    - Complete filesystem isolation (only workspace mounted)
    - Network isolation (optional)
    - Resource limits (CPU, memory)
    - Automatic cleanup after execution

    Note: Requires Docker to be installed and running. Will fail gracefully
    if Docker is not available.

    Attributes:
        image: Docker image to use for execution.
        network_disabled: If True, disable network access in container.
        memory_limit: Memory limit for container (e.g., "512m").
        cpu_limit: CPU limit for container (e.g., 0.5 for half a core).
    """

    DEFAULT_IMAGE = "python:3.11-slim"

    def __init__(
        self,
        workspace_root: str,
        timeout: int = 30,
        image: Optional[str] = None,
        permission_manager: Optional[PermissionManager] = None,
        auto_confirm_dangerous: bool = False,
        network_disabled: bool = False,
        memory_limit: str = "512m",
        cpu_limit: float = 1.0,
        log_file: Optional[str] = None,
    ):
        """Initialize the Docker executor.

        Args:
            workspace_root: Root directory for file operations (will be mounted).
            timeout: Default timeout in seconds.
            image: Docker image to use. Defaults to python:3.11-slim.
            permission_manager: Custom permission manager.
            auto_confirm_dangerous: Skip confirmation for dangerous commands.
            network_disabled: Disable network access in container.
            memory_limit: Memory limit for container.
            cpu_limit: CPU limit for container.
            log_file: Path to audit log file.
        """
        super().__init__(workspace_root, timeout)

        self.image = image or self.DEFAULT_IMAGE
        self.permission_manager = permission_manager or PermissionManager()
        self.auto_confirm_dangerous = auto_confirm_dangerous
        self.network_disabled = network_disabled
        self.memory_limit = memory_limit
        self.cpu_limit = cpu_limit

        # Setup logging
        self.logger = logging.getLogger("miniagent.executor.docker")
        self.logger.setLevel(logging.INFO)

        if log_file:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_file)
            file_handler.setFormatter(
                logging.Formatter(
                    "%(asctime)s - %(levelname)s - %(message)s",
                    datefmt="%Y-%m-%d %H:%M:%S",
                )
            )
            self.logger.addHandler(file_handler)

        # Check Docker availability
        self._docker_available = self._check_docker()
        if not self._docker_available:
            self.logger.warning("Docker not available - executor will fail")

    @classmethod
    def _check_docker(cls) -> bool:
        """Check if Docker is available and running.

        Returns:
            True if Docker daemon is accessible, False otherwise.
        """
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            return result.returncode == 0
        except (subprocess.SubprocessError, FileNotFoundError, OSError):
            return False

    @property
    def is_available(self) -> bool:
        """Check if Docker executor can be used.

        Returns:
            True if Docker is available and running.
        """
        return self._docker_available

    def _build_docker_run_args(
        self,
        command: Union[str, list[str]],
        cwd: str,
        timeout: int,
        shell: bool = False,
    ) -> list[str]:
        """Build docker run command arguments.

        Args:
            command: Command to execute.
            cwd: Working directory inside container.
            timeout: Timeout in seconds.
            shell: Whether to run through shell.

        Returns:
            List of arguments for subprocess.run.
        """
        # Build docker run command
        args = [
            "docker",
            "run",
            "--rm",  # Auto-remove container
            "-v", f"{self.workspace_root}:/workspace",  # Mount workspace
            "-w", cwd,  # Working directory
            "--memory", self.memory_limit,
            "--cpus", str(self.cpu_limit),
            "--pids-limit", "100",  # Limit processes
        ]

        if self.network_disabled:
            args.append("--network=none")

        # Add timeout as docker run doesn't have native timeout
        # We'll handle timeout in subprocess.run instead

        args.append(self.image)

        if shell:
            args.extend(["/bin/sh", "-c", command if isinstance(command, str) else " ".join(command)])
        else:
            if isinstance(command, str):
                # Simple split for string commands
                args.extend(command.split())
            else:
                args.extend(command)

        return args

    def _log_execution(self, result: ExecutionResult, container_id: str = "") -> None:
        """Log execution details.

        Args:
            result: Execution result to log.
            container_id: Docker container ID if available.
        """
        log_entry = {
            "timestamp": result.timestamp.isoformat(),
            "command": result.command,
            "cwd": result.cwd,
            "success": result.success,
            "exit_code": result.exit_code,
            "duration_ms": result.duration_ms,
            "container_id": container_id,
        }

        if result.success:
            self.logger.info(f"DOCKER EXEC: {log_entry}")
        else:
            self.logger.warning(f"DOCKER EXEC FAILED: {log_entry} - Error: {result.error_message}")

    def run_command(
        self,
        command: Union[str, list[str]],
        cwd: Optional[str] = None,
        timeout: Optional[int] = None,
        shell: bool = False,
    ) -> ExecutionResult:
        """Execute a command inside a Docker container.

        Args:
            command: Command to execute.
            cwd: Working directory inside container (relative to /workspace).
            timeout: Timeout in seconds.
            shell: Whether to run through shell.

        Returns:
            ExecutionResult with output and metadata.
        """
        start_time = datetime.now()

        if not self._docker_available:
            return ExecutionResult.failure_result(
                error_message="Docker is not available on this system",
                command=command if isinstance(command, str) else " ".join(command),
            )

        # Normalize command
        command_str = command if isinstance(command, str) else " ".join(command)

        # Check permissions
        perm_result = self.permission_manager.check_command(command_str)
        if perm_result.blocked:
            return ExecutionResult.failure_result(
                error_message=f"Command blocked: {perm_result.description}",
                command=command_str,
            )

        if perm_result.requires_confirmation and not self.auto_confirm_dangerous:
            prompt = self.permission_manager.get_confirmation_prompt(command_str)
            print(prompt)
            try:
                response = input().strip().lower()
                if response not in ("y", "yes"):
                    return ExecutionResult.failure_result(
                        error_message="User denied confirmation",
                        command=command_str,
                    )
            except (EOFError, KeyboardInterrupt):
                return ExecutionResult.failure_result(
                    error_message="Confirmation cancelled",
                    command=command_str,
                )

        # Resolve working directory
        if cwd is None:
            exec_cwd = "/workspace"
        else:
            # Validate path is within workspace
            try:
                validated = self.validate_path(cwd)
                # Convert to container path
                exec_cwd = "/workspace" + validated[len(self.workspace_root):]
            except PermissionError as e:
                return ExecutionResult.failure_result(
                    error_message=str(e),
                    command=command_str,
                )

        # Build docker command
        effective_timeout = timeout or self.timeout
        docker_args = self._build_docker_run_args(
            command=command,
            cwd=exec_cwd,
            timeout=effective_timeout,
            shell=shell,
        )

        # Execute
        container_id = ""
        try:
            process = subprocess.run(
                docker_args,
                capture_output=True,
                text=True,
                timeout=effective_timeout,
            )

            duration_ms = (datetime.now() - start_time).total_seconds() * 1000

            # Extract container ID from output if available
            container_id = ""  # Would need --cidfile to get this reliably

            result = ExecutionResult(
                success=process.returncode == 0,
                stdout=process.stdout,
                stderr=process.stderr,
                exit_code=process.returncode,
                duration_ms=duration_ms,
                timestamp=datetime.now(),
                command=command_str,
                cwd=exec_cwd,
            )

            self._log_execution(result, container_id)
            return result

        except subprocess.TimeoutExpired as e:
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            result = ExecutionResult.failure_result(
                error_message=f"Docker command timed out after {effective_timeout}s",
                command=command_str,
                duration_ms=duration_ms,
                stderr=e.stderr if isinstance(e.stderr, str) else str(e.stderr),
                exit_code=-9,
            )
            self._log_execution(result, container_id)
            return result

        except FileNotFoundError:
            return ExecutionResult.failure_result(
                error_message="Docker command not found",
                command=command_str,
            )

        except Exception as e:
            duration_ms = (datetime.now() - start_time).total_seconds() * 1000
            result = ExecutionResult.failure_result(
                error_message=f"Docker execution failed: {str(e)}",
                command=command_str,
                duration_ms=duration_ms,
                stderr=str(e),
                exit_code=-1,
            )
            self._log_execution(result, container_id)
            return result

    def read_file(self, path: str) -> str:
        """Read a file from the workspace.

        Since files are in the mounted volume, we can read them directly
        from the host filesystem.

        Args:
            path: Path to file.

        Returns:
            File contents.

        Raises:
            FileNotFoundError: If file doesn't exist.
            PermissionError: If path is outside workspace.
        """
        validated_path = self.validate_path(path)

        if not os.path.exists(validated_path):
            raise FileNotFoundError(f"File not found: {path}")

        if os.path.isdir(validated_path):
            raise IsADirectoryError(f"Path is a directory: {path}")

        with open(validated_path, "r", encoding="utf-8") as f:
            return f.read()

    def write_file(self, path: str, content: str, create_dirs: bool = True) -> None:
        """Write content to a file in the workspace.

        Files written here will be visible inside containers.

        Args:
            path: Path to file.
            content: Content to write.
            create_dirs: Create parent directories if needed.

        Raises:
            PermissionError: If path is outside workspace.
        """
        validated_path = self.validate_path(path)

        if create_dirs:
            parent = Path(validated_path).parent
            parent.mkdir(parents=True, exist_ok=True)

        with open(validated_path, "w", encoding="utf-8") as f:
            f.write(content)

        self.logger.info(f"WRITE: {path} ({len(content)} bytes)")

    def file_exists(self, path: str) -> bool:
        """Check if a file exists in the workspace.

        Args:
            path: Path to check.

        Returns:
            True if file exists.
        """
        try:
            validated_path = self.validate_path(path)
            return os.path.isfile(validated_path)
        except PermissionError:
            return False

    def list_directory(self, path: str) -> list[str]:
        """List contents of a directory.

        Args:
            path: Path to directory.

        Returns:
            List of filenames.

        Raises:
            NotADirectoryError: If path is not a directory.
        """
        validated_path = self.validate_path(path)

        if not os.path.isdir(validated_path):
            raise NotADirectoryError(f"Path is not a directory: {path}")

        return os.listdir(validated_path)


def is_docker_available() -> bool:
    """Check if Docker is available on the system.

    Returns:
        True if Docker daemon is running and accessible.
    """
    return DockerExecutor._check_docker()


def create_executor(
    workspace_root: str,
    timeout: int = 30,
    prefer_docker: bool = False,
    **kwargs,
) -> Executor:
    """Factory function to create appropriate executor.

    Args:
        workspace_root: Root directory for file operations.
        timeout: Default timeout in seconds.
        prefer_docker: If True, try Docker first; fallback to subprocess.
        **kwargs: Additional arguments passed to executor constructors.

    Returns:
        Executor instance (DockerExecutor or SubprocessExecutor).
    """
    if prefer_docker and DockerExecutor.is_docker_available():
        logging.getLogger("miniagent.executor").info("Using Docker executor")
        return DockerExecutor(workspace_root, timeout, **kwargs)
    else:
        if prefer_docker:
            logging.getLogger("miniagent.executor").warning(
                "Docker not available, falling back to SubprocessExecutor"
            )
        # Import here to avoid circular dependency
        from miniagent.executor.subprocess_executor import SubprocessExecutor
        return SubprocessExecutor(workspace_root, timeout, **kwargs)
