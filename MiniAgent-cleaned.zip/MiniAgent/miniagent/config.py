"""
MiniAgent Configuration Module

This module handles loading and validating configuration from config.yaml
using Pydantic for type-safe configuration management.

Supports environment variable substitution using ${VAR_NAME} syntax.
"""

import os
import re
from pathlib import Path
from typing import Any, Optional

import yaml
from pydantic import BaseModel, Field, field_validator


class LLMConfig(BaseModel):
    """Configuration for LLM providers and generation parameters."""
    
    primary: str = Field(
        default="openrouter/qwen/qwen-2.5-coder-32b-instruct",
        description="Primary LLM provider in format 'provider/model'"
    )
    fallback: list[str] = Field(
        default_factory=list,
        description="List of fallback providers in order of preference"
    )
    api_keys: dict[str, str] = Field(
        default_factory=dict,
        description="API keys for different providers (supports ${ENV_VAR} syntax)"
    )
    temperature: float = Field(
        default=0.3,
        ge=0.0,
        le=2.0,
        description="Sampling temperature for LLM generation"
    )
    max_tokens: int = Field(
        default=4096,
        gt=0,
        description="Maximum tokens to generate"
    )
    max_retries: int = Field(
        default=2,
        ge=0,
        description="Maximum retry attempts on failure"
    )
    retry_delay: float = Field(
        default=1.0,
        ge=0.0,
        description="Delay between retries in seconds"
    )
    
    @field_validator("api_keys", mode="before")
    @classmethod
    def resolve_env_vars(cls, v: dict[str, Any]) -> dict[str, Any]:
        """Resolve environment variables in API key values."""
        if not isinstance(v, dict):
            return v
        
        resolved = {}
        env_pattern = re.compile(r"^\$\{([^}]+)\}$")
        
        for key, value in v.items():
            if isinstance(value, str):
                match = env_pattern.match(value)
                if match:
                    env_var = match.group(1)
                    resolved[key] = os.environ.get(env_var, "")
                else:
                    resolved[key] = value
            else:
                resolved[key] = value
        
        return resolved


class ExecutorConfig(BaseModel):
    """Configuration for command executor."""
    
    type: str = Field(
        default="subprocess",
        description="Executor type: 'subprocess' or 'docker'"
    )
    timeout: int = Field(
        default=30,
        gt=0,
        description="Default timeout for command execution in seconds"
    )
    workspace: str = Field(
        default="./workspace",
        description="Working directory restriction for file operations"
    )
    auto_confirm_safe: bool = Field(
        default=True,
        description="Auto-confirm safe commands without asking user"
    )


class MemoryConfig(BaseModel):
    """Configuration for memory management."""
    
    short_term_window: int = Field(
        default=20,
        gt=0,
        description="Number of recent messages to keep in short-term memory"
    )
    long_term_enabled: bool = Field(
        default=True,
        description="Enable long-term memory persistence"
    )
    storage_backend: str = Field(
        default="json",
        description="Storage backend: 'json' or 'sqlite'"
    )


class PipelineConfig(BaseModel):
    """Configuration for reasoning pipeline."""
    
    max_review_retries: int = Field(
        default=3,
        gt=0,
        description="Maximum retry attempts when self-review fails"
    )
    log_stages: bool = Field(
        default=True,
        description="Log output from each stage"
    )
    persist_state: bool = Field(
        default=True,
        description="Persist pipeline state for resume capability"
    )


class SafetyConfig(BaseModel):
    """Configuration for safety rules."""
    
    dangerous_commands: list[str] = Field(
        default_factory=lambda: [
            "rm -rf", "rm -r", "sudo", "mkfs", "dd",
            "chmod -R", "chown -R", ":(){:|:&};:",
            "> /dev/", "curl * | bash", "wget * | bash",
            "eval", "exec"
        ],
        description="Commands that always require explicit user confirmation"
    )
    safe_commands: list[str] = Field(
        default_factory=lambda: [
            "ls", "cat", "head", "tail", "grep", "find", "pwd", "echo",
            "python", "python3", "pip", "pip3", "git", "npm", "npx",
            "yarn", "node", "mkdir", "touch", "cp", "mv"
        ],
        description="Commands considered safe for auto-execution"
    )


class LoggingConfig(BaseModel):
    """Configuration for logging."""
    
    level: str = Field(
        default="INFO",
        description="Log level: DEBUG, INFO, WARNING, ERROR"
    )
    file: str = Field(
        default=".miniagent/logs/miniagent.log",
        description="Log file location"
    )
    include_timestamp: bool = Field(
        default=True,
        description="Include timestamps in logs"
    )


class Config(BaseModel):
    """Main configuration container."""
    
    llm: LLMConfig = Field(default_factory=LLMConfig)
    executor: ExecutorConfig = Field(default_factory=ExecutorConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    pipeline: PipelineConfig = Field(default_factory=PipelineConfig)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)
    logging: LoggingConfig = Field(default_factory=LoggingConfig)
    
    # Internal path tracking
    _config_path: Optional[Path] = None
    _base_dir: Optional[Path] = None
    
    @classmethod
    def load(cls, config_path: Optional[str] = None) -> "Config":
        """
        Load configuration from YAML file.
        
        Args:
            config_path: Path to config file. If None, searches for
                        config.yaml in current dir, then home dir.
        
        Returns:
            Config instance with loaded values.
        
        Raises:
            FileNotFoundError: If no config file is found.
            yaml.YAMLError: If config file is malformed.
        """
        # Determine config path
        if config_path:
            path = Path(config_path)
        else:
            # Search order: current dir, then home dir
            path = Path("config.yaml")
            if not path.exists():
                home_config = Path.home() / ".miniagent" / "config.yaml"
                if home_config.exists():
                    path = home_config
                else:
                    # Fall back to example config if exists
                    example = Path("config.example.yaml")
                    if example.exists():
                        path = example
                    else:
                        # Return default config
                        return cls()
        
        if not path.exists():
            return cls()
        
        # Load YAML
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        
        # Create config instance
        config = cls.model_validate(data)
        config._config_path = path.absolute()
        config._base_dir = path.parent
        
        return config
    
    def get_workspace_path(self) -> Path:
        """
        Get absolute path to workspace directory.
        
        Returns:
            Absolute Path to workspace directory.
        """
        ws = self.executor.workspace
        if ws.startswith("./") or ws.startswith("../"):
            base = self._base_dir or Path.cwd()
            return (base / ws).resolve()
        return Path(ws).resolve()
    
    def get_data_dir(self) -> Path:
        """
        Get path to data directory (.miniagent).
        
        Returns:
            Path to .miniagent directory.
        """
        base = self._base_dir or Path.cwd()
        return base / ".miniagent"
    
    def ensure_directories(self) -> None:
        """Create necessary directories if they don't exist."""
        dirs = [
            self.get_workspace_path(),
            self.get_data_dir() / "sessions",
            self.get_data_dir() / "logs",
        ]
        for d in dirs:
            d.mkdir(parents=True, exist_ok=True)


# Global config instance (lazy loaded)
_config: Optional[Config] = None


def get_config(reload: bool = False) -> Config:
    """
    Get global configuration instance.
    
    Args:
        reload: If True, reload config from file.
    
    Returns:
        Config instance.
    """
    global _config
    
    if _config is None or reload:
        _config = Config.load()
        _config.ensure_directories()
    
    return _config


def reload_config() -> Config:
    """
    Force reload configuration from file.
    
    Returns:
        Reloaded Config instance.
    """
    return get_config(reload=True)
