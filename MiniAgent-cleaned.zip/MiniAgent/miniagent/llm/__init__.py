"""
LLM module for MiniAgent.

Provides multi-provider LLM support via litellm with:
- Automatic fallback across providers
- Retry logic with exponential backoff
- Provider capability detection
- Model alias resolution
"""

from miniagent.llm.client import (
    LLMClient,
    LLMResponse,
    Message,
    quick_complete,
    create_client_for_capability,
)
from miniagent.llm.providers import (
    ProviderCapability,
    ProviderInfo,
    PROVIDERS,
    MODEL_ALIASES,
    resolve_model_alias,
    get_provider_info,
    list_providers,
    list_aliases,
    get_local_providers,
    get_free_tier_providers,
    get_fastest_providers,
    get_cheapest_providers,
    supports_capability,
    select_best_provider,
)

__all__ = [
    # Client classes
    "LLMClient",
    "LLMResponse",
    "Message",
    
    # Convenience functions
    "quick_complete",
    "create_client_for_capability",
    
    # Provider types
    "ProviderCapability",
    "ProviderInfo",
    
    # Provider data
    "PROVIDERS",
    "MODEL_ALIASES",
    
    # Provider utilities
    "resolve_model_alias",
    "get_provider_info",
    "list_providers",
    "list_aliases",
    "get_local_providers",
    "get_free_tier_providers",
    "get_fastest_providers",
    "get_cheapest_providers",
    "supports_capability",
    "select_best_provider",
]
