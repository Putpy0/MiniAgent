"""
MiniAgent LLM Providers Module

This module defines provider aliases, configurations, and capabilities
for litellm, enabling consistent model naming across different LLM providers.
Supports provider capability detection, rate limit tracking, and model routing.
"""

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Optional
import logging

logger = logging.getLogger(__name__)


class ProviderCapability(Enum):
    """Capabilities that different providers may support."""
    STREAMING = auto()
    JSON_MODE = auto()
    FUNCTION_CALLING = auto()
    VISION = auto()
    LARGE_CONTEXT = auto()
    FAST_INFERENCE = auto()
    LOCAL_EXECUTION = auto()
    FREE_TIER = auto()


@dataclass(frozen=True)
class ProviderInfo:
    """
    Comprehensive information about an LLM provider.
    
    Attributes:
        name: Provider identifier used in litellm
        display_name: Human-readable provider name
        supports_streaming: Whether this provider supports streaming responses
        supports_json_mode: Whether JSON-only response format is supported
        supports_function_calling: Whether tool/function calling is supported
        supports_vision: Whether image input is supported
        requires_api_key: Whether this provider requires an API key
        api_key_env_var: Environment variable name for the API key
        base_url: Custom base URL for the provider (if applicable)
        max_context_length: Maximum context length in tokens
        max_output_tokens: Maximum output tokens per request
        rate_limit_tier: Rate limit tier (free, standard, premium, unlimited)
        avg_latency_ms: Average latency in milliseconds (for estimation)
        cost_per_million_input: Cost per 1M input tokens (USD)
        cost_per_million_output: Cost per 1M output tokens (USD)
        capabilities: Set of supported capabilities
        is_fallback_safe: Whether safe to use as automatic fallback
    """
    
    name: str
    display_name: str
    
    # Capability flags
    supports_streaming: bool = True
    supports_json_mode: bool = True
    supports_function_calling: bool = False
    supports_vision: bool = False
    
    # Authentication
    requires_api_key: bool = True
    api_key_env_var: Optional[str] = None
    base_url: Optional[str] = None
    
    # Limits
    max_context_length: int = 128_000
    max_output_tokens: int = 4096
    
    # Rate limiting
    rate_limit_tier: str = "standard"  # free, standard, premium, unlimited
    avg_latency_ms: int = 2000
    
    # Pricing (USD per 1M tokens)
    cost_per_million_input: float = 0.0
    cost_per_million_output: float = 0.0
    
    # Capabilities set
    capabilities: set[ProviderCapability] = field(default_factory=set)
    
    # Fallback configuration
    is_fallback_safe: bool = True
    
    def has_capability(self, cap: ProviderCapability) -> bool:
        """Check if provider has a specific capability."""
        return cap in self.capabilities
    
    @property
    def is_local(self) -> bool:
        """Check if this is a local provider (no API key required)."""
        return not self.requires_api_key
    
    @property
    def is_free_tier(self) -> bool:
        """Check if provider offers free tier."""
        return self.rate_limit_tier == "free" or ProviderCapability.FREE_TIER in self.capabilities


# Provider definitions with comprehensive metadata
PROVIDERS: dict[str, ProviderInfo] = {
    # OpenRouter - gateway to multiple models
    "openrouter": ProviderInfo(
        name="openrouter",
        display_name="OpenRouter",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=True,
        requires_api_key=True,
        api_key_env_var="OPENROUTER_API_KEY",
        max_context_length=128_000,
        max_output_tokens=4096,
        rate_limit_tier="standard",
        avg_latency_ms=3000,
        cost_per_million_input=0.50,
        cost_per_million_output=1.50,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
            ProviderCapability.FUNCTION_CALLING,
            ProviderCapability.LARGE_CONTEXT,
        },
        is_fallback_safe=True,
    ),
    
    # Groq - fastest inference
    "groq": ProviderInfo(
        name="groq",
        display_name="Groq",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=False,
        requires_api_key=True,
        api_key_env_var="GROQ_API_KEY",
        max_context_length=32_000,
        max_output_tokens=4096,
        rate_limit_tier="standard",
        avg_latency_ms=200,  # Extremely fast
        cost_per_million_input=0.0,  # Free tier available
        cost_per_million_output=0.0,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
            ProviderCapability.FAST_INFERENCE,
            ProviderCapability.FREE_TIER,
        },
        is_fallback_safe=True,
    ),
    
    # DeepSeek - cost-effective high performance
    "deepseek": ProviderInfo(
        name="deepseek",
        display_name="DeepSeek",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=False,
        requires_api_key=True,
        api_key_env_var="DEEPSEEK_API_KEY",
        max_context_length=128_000,
        max_output_tokens=4096,
        rate_limit_tier="standard",
        avg_latency_ms=1500,
        cost_per_million_input=0.14,
        cost_per_million_output=0.28,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
            ProviderCapability.LARGE_CONTEXT,
        },
        is_fallback_safe=True,
    ),
    
    # Anthropic (Claude) - highest quality
    "anthropic": ProviderInfo(
        name="anthropic",
        display_name="Anthropic",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=True,
        supports_vision=True,
        requires_api_key=True,
        api_key_env_var="ANTHROPIC_API_KEY",
        max_context_length=200_000,
        max_output_tokens=4096,
        rate_limit_tier="premium",
        avg_latency_ms=4000,
        cost_per_million_input=3.00,
        cost_per_million_output=15.00,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
            ProviderCapability.FUNCTION_CALLING,
            ProviderCapability.VISION,
            ProviderCapability.LARGE_CONTEXT,
        },
        is_fallback_safe=False,  # Expensive, use carefully
    ),
    
    # OpenAI - versatile and reliable
    "openai": ProviderInfo(
        name="openai",
        display_name="OpenAI",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=True,
        supports_vision=True,
        requires_api_key=True,
        api_key_env_var="OPENAI_API_KEY",
        max_context_length=128_000,
        max_output_tokens=4096,
        rate_limit_tier="premium",
        avg_latency_ms=2500,
        cost_per_million_input=2.50,
        cost_per_million_output=10.00,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
            ProviderCapability.FUNCTION_CALLING,
            ProviderCapability.VISION,
            ProviderCapability.LARGE_CONTEXT,
        },
        is_fallback_safe=False,
    ),
    
    # DashScope (Alibaba Cloud / Qwen)
    "dashscope": ProviderInfo(
        name="dashscope",
        display_name="DashScope (Alibaba)",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=False,
        requires_api_key=True,
        api_key_env_var="DASHSCOPE_API_KEY",
        max_context_length=32_000,
        max_output_tokens=2048,
        rate_limit_tier="standard",
        avg_latency_ms=2000,
        cost_per_million_input=0.50,
        cost_per_million_output=1.00,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
        },
        is_fallback_safe=True,
    ),
    
    # Ollama - local models (no API key required)
    "ollama": ProviderInfo(
        name="ollama",
        display_name="Ollama (Local)",
        supports_streaming=True,
        supports_json_mode=False,  # Depends on model
        supports_function_calling=False,
        requires_api_key=False,
        max_context_length=32_000,
        max_output_tokens=2048,
        rate_limit_tier="unlimited",
        avg_latency_ms=5000,  # Depends on hardware
        cost_per_million_input=0.0,
        cost_per_million_output=0.0,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.LOCAL_EXECUTION,
            ProviderCapability.FREE_TIER,
        },
        is_fallback_safe=True,  # Great fallback, no cost
    ),
    
    # LM Studio - local models via HTTP
    "lm_studio": ProviderInfo(
        name="lm_studio",
        display_name="LM Studio (Local)",
        supports_streaming=True,
        supports_json_mode=False,
        supports_function_calling=False,
        requires_api_key=False,
        base_url="http://localhost:1234/v1",
        max_context_length=16_000,
        max_output_tokens=2048,
        rate_limit_tier="unlimited",
        avg_latency_ms=6000,
        cost_per_million_input=0.0,
        cost_per_million_output=0.0,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.LOCAL_EXECUTION,
            ProviderCapability.FREE_TIER,
        },
        is_fallback_safe=True,
    ),
    
    # vLLM - self-hosted inference server
    "vllm": ProviderInfo(
        name="vllm",
        display_name="vLLM (Self-hosted)",
        supports_streaming=True,
        supports_json_mode=False,
        supports_function_calling=False,
        requires_api_key=False,
        base_url="http://localhost:8000/v1",
        max_context_length=32_000,
        max_output_tokens=4096,
        rate_limit_tier="unlimited",
        avg_latency_ms=3000,
        cost_per_million_input=0.0,
        cost_per_million_output=0.0,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.LOCAL_EXECUTION,
            ProviderCapability.FREE_TIER,
            ProviderCapability.FAST_INFERENCE,
        },
        is_fallback_safe=True,
    ),
    
    # Together AI - cloud inference
    "together_ai": ProviderInfo(
        name="together_ai",
        display_name="Together AI",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=False,
        requires_api_key=True,
        api_key_env_var="TOGETHER_AI_API_KEY",
        max_context_length=32_000,
        max_output_tokens=4096,
        rate_limit_tier="standard",
        avg_latency_ms=2500,
        cost_per_million_input=0.90,
        cost_per_million_output=0.90,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
        },
        is_fallback_safe=True,
    ),
    
    # Fireworks AI
    "fireworks_ai": ProviderInfo(
        name="fireworks_ai",
        display_name="Fireworks AI",
        supports_streaming=True,
        supports_json_mode=True,
        supports_function_calling=True,
        requires_api_key=True,
        api_key_env_var="FIREWORKS_AI_API_KEY",
        max_context_length=16_000,
        max_output_tokens=4096,
        rate_limit_tier="standard",
        avg_latency_ms=2000,
        cost_per_million_input=0.90,
        cost_per_million_output=0.90,
        capabilities={
            ProviderCapability.STREAMING,
            ProviderCapability.JSON_MODE,
            ProviderCapability.FUNCTION_CALLING,
        },
        is_fallback_safe=True,
    ),
}


# Model aliases - convenient shortcuts for commonly used models
MODEL_ALIASES: dict[str, str] = {
    # ===== Qwen Models =====
    "qwen-coder": "openrouter/qwen/qwen-2.5-coder-32b-instruct",
    "qwen-coder-local": "ollama/qwen2.5-coder",
    "qwen-turbo": "dashscope/qwen-turbo",
    "qwen-plus": "dashscope/qwen-plus",
    "qwen-max": "dashscope/qwen-max",
    "qwen-72b": "openrouter/qwen/qwen-2.5-72b-instruct",
    
    # ===== Llama Models =====
    "llama-3-70b": "groq/llama-3.3-70b-versatile",
    "llama-3-8b": "groq/llama-3.1-8b-instant",
    "llama-3-70b-local": "ollama/llama3.1",
    
    # ===== Claude Models =====
    "claude-sonnet": "anthropic/claude-3-5-sonnet-20241022",
    "claude-haiku": "anthropic/claude-3-5-haiku-20241022",
    "claude-opus": "anthropic/claude-3-opus-20240229",
    "claude-sonnet-openrouter": "openrouter/anthropic/claude-3-5-sonnet",
    
    # ===== GPT Models =====
    "gpt-4o": "openai/gpt-4o",
    "gpt-4o-mini": "openai/gpt-4o-mini",
    "gpt-4-turbo": "openai/gpt-4-turbo-preview",
    "gpt-4o-openrouter": "openrouter/openai/gpt-4o",
    
    # ===== DeepSeek Models =====
    "deepseek-coder": "deepseek/deepseek-coder",
    "deepseek-chat": "deepseek/deepseek-chat",
    "deepseek-v3": "deepseek/deepseek-v3",
    
    # ===== Local Models (Ollama) =====
    "local-qwen": "ollama/qwen2.5-coder",
    "local-llama": "ollama/llama3.1",
    "local-mistral": "ollama/mistral",
    "local-deepseek": "ollama/deepseek-coder",
    "local-codellama": "ollama/codellama",
    
    # ===== Fast/Cheap Options =====
    "fast": "groq/llama-3.3-70b-versatile",
    "cheap": "deepseek/deepseek-chat",
    "free": "ollama/qwen2.5-coder",
}


def resolve_model_alias(model_identifier: str) -> str:
    """
    Resolve a model alias to its full provider/model format.
    
    Priority:
    1. If contains '/', assume already in full format
    2. Check MODEL_ALIASES dictionary
    3. Return as-is (litellm will handle it)
    
    Args:
        model_identifier: Either an alias (e.g., 'qwen-coder') or 
                         full identifier (e.g., 'openrouter/qwen/...').
    
    Returns:
        Full model identifier in 'provider/model' format.
    
    Examples:
        >>> resolve_model_alias("qwen-coder")
        'openrouter/qwen/qwen-2.5-coder-32b-instruct'
        >>> resolve_model_alias("openai/gpt-4o")
        'openai/gpt-4o'
        >>> resolve_model_alias("unknown-model")
        'unknown-model'
    """
    if "/" in model_identifier:
        # Already in full format
        return model_identifier
    
    # Try to resolve alias
    resolved = MODEL_ALIASES.get(model_identifier)
    if resolved:
        logger.debug(f"Resolved alias '{model_identifier}' -> '{resolved}'")
        return resolved
    
    # Return as-is, litellm will attempt to handle it
    logger.warning(f"Unknown model alias: {model_identifier}, using as-is")
    return model_identifier


def get_provider_info(model_identifier: str) -> Optional[ProviderInfo]:
    """
    Get provider information for a given model identifier.
    
    Args:
        model_identifier: Model identifier in 'provider/model' format or alias.
    
    Returns:
        ProviderInfo if found, None otherwise.
    
    Examples:
        >>> info = get_provider_info("openai/gpt-4o")
        >>> info.display_name
        'OpenAI'
        >>> info.is_local
        False
    """
    resolved = resolve_model_alias(model_identifier)
    
    # Extract provider name (first part before '/')
    parts = resolved.split("/", 1)
    if len(parts) < 2:
        logger.warning(f"Could not extract provider from: {model_identifier}")
        return None
    
    provider_name = parts[0]
    provider_info = PROVIDERS.get(provider_name)
    
    if not provider_info:
        logger.debug(f"Unknown provider: {provider_name}")
    
    return provider_info


def list_providers() -> list[ProviderInfo]:
    """
    List all available providers.
    
    Returns:
        List of ProviderInfo objects sorted by display name.
    """
    return sorted(PROVIDERS.values(), key=lambda p: p.display_name)


def list_aliases() -> dict[str, str]:
    """
    List all model aliases.
    
    Returns:
        Dictionary mapping aliases to full model identifiers.
    """
    return MODEL_ALIASES.copy()


def get_local_providers() -> list[str]:
    """
    Get list of providers that run locally (no API key required).
    
    Returns:
        List of provider names that are local.
    """
    return [p.name for p in PROVIDERS.values() if p.is_local]


def get_free_tier_providers() -> list[str]:
    """
    Get list of providers with free tier availability.
    
    Returns:
        List of provider names offering free tier.
    """
    return [
        p.name for p in PROVIDERS.values() 
        if p.is_free_tier or p.rate_limit_tier == "free"
    ]


def get_fastest_providers(limit: int = 3) -> list[str]:
    """
    Get list of fastest providers by average latency.
    
    Args:
        limit: Maximum number of providers to return.
    
    Returns:
        List of provider names sorted by latency (fastest first).
    """
    sorted_providers = sorted(
        PROVIDERS.values(),
        key=lambda p: p.avg_latency_ms
    )
    return [p.name for p in sorted_providers[:limit]]


def get_cheapest_providers(limit: int = 3) -> list[str]:
    """
    Get list of cheapest providers by input token cost.
    
    Args:
        limit: Maximum number of providers to return.
    
    Returns:
        List of provider names sorted by cost (cheapest first).
    """
    sorted_providers = sorted(
        PROVIDERS.values(),
        key=lambda p: (p.cost_per_million_input, p.cost_per_million_output)
    )
    return [p.name for p in sorted_providers[:limit]]


def supports_capability(provider_name: str, capability: ProviderCapability) -> bool:
    """
    Check if a provider supports a specific capability.
    
    Args:
        provider_name: Name of the provider.
        capability: Capability to check.
    
    Returns:
        True if provider supports the capability.
    """
    provider = PROVIDERS.get(provider_name)
    if not provider:
        return False
    return provider.has_capability(capability)


def select_best_provider(
    required_capabilities: Optional[list[ProviderCapability]] = None,
    require_local: bool = False,
    require_free: bool = False,
    max_latency_ms: Optional[int] = None,
) -> Optional[str]:
    """
    Select the best provider based on requirements.
    
    Args:
        required_capabilities: List of required capabilities.
        require_local: If True, only consider local providers.
        require_free: If True, only consider free tier providers.
        max_latency_ms: Maximum acceptable latency in milliseconds.
    
    Returns:
        Best matching provider name, or None if no match.
    """
    candidates = list(PROVIDERS.values())
    
    # Filter by requirements
    if require_local:
        candidates = [p for p in candidates if p.is_local]
    
    if require_free:
        candidates = [p for p in candidates if p.is_free_tier]
    
    if max_latency_ms is not None:
        candidates = [p for p in candidates if p.avg_latency_ms <= max_latency_ms]
    
    if required_capabilities:
        candidates = [
            p for p in candidates
            if all(p.has_capability(cap) for cap in required_capabilities)
        ]
    
    if not candidates:
        return None
    
    # Sort by cost then latency
    best = min(
        candidates,
        key=lambda p: (p.cost_per_million_input + p.cost_per_million_output, p.avg_latency_ms)
    )
    
    return best.name
