"""
MiniAgent LLM Client Module

Multi-provider LLM client with automatic fallback, retry logic, and
comprehensive error handling. Built on top of litellm for unified API access.

Features:
- Automatic fallback across multiple providers
- Retry with exponential backoff
- JSON mode support
- Streaming support
- Token usage tracking
- Provider capability detection
"""

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union

import litellm
from litellm import completion as litellm_completion
from litellm.exceptions import (
    APIConnectionError,
    AuthenticationError,
    BadRequestError,
    RateLimitError,
    Timeout,
)

from miniagent.config import get_config
from miniagent.llm.providers import (
    ProviderCapability,
    get_provider_info,
    resolve_model_alias,
    select_best_provider,
)

logger = logging.getLogger(__name__)


@dataclass
class LLMResponse:
    """Structured response from LLM completion."""

    content: str
    model: str
    provider: str
    usage: Dict[str, int] = field(default_factory=dict)
    raw_response: Optional[Any] = None
    error: Optional[str] = None
    fallback_used: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert response to dictionary."""
        return {
            "content": self.content,
            "model": self.model,
            "provider": self.provider,
            "usage": self.usage,
            "error": self.error,
            "fallback_used": self.fallback_used,
        }

    @property
    def is_json(self) -> bool:
        """Check if response content is JSON."""
        try:
            json.loads(self.content.strip())
            return True
        except (json.JSONDecodeError, ValueError):
            return False

    def parse_json(self) -> Dict[str, Any]:
        """Parse response content as JSON.
        
        Returns:
            Parsed JSON as dictionary
            
        Raises:
            json.JSONDecodeError: If content is not valid JSON
        """
        return json.loads(self.content.strip())


@dataclass
class Message:
    """A single message in a conversation."""

    role: str  # "system", "user", or "assistant"
    content: str

    def to_dict(self) -> Dict[str, str]:
        """Convert to dict format for litellm."""
        return {"role": self.role, "content": self.content}


class LLMClient:
    """
    Multi-provider LLM client with automatic fallback support.
    
    This client wraps litellm to provide:
    - Unified interface across all providers
    - Automatic fallback to backup providers on failure
    - Retry logic with exponential backoff
    - Structured response handling
    - Token usage tracking
    
    Example:
        >>> config = get_config()
        >>> client = LLMClient(config)
        >>> response = client.complete("Hello, world!")
        >>> print(response.content)
    """

    def __init__(
        self,
        primary_model: Optional[str] = None,
        fallback_models: Optional[List[str]] = None,
        temperature: float = 0.3,
        max_tokens: int = 4096,
        max_retries: int = 2,
        timeout: int = 60,
        enable_streaming: bool = False,
        require_json_mode: bool = False,
    ):
        """
        Initialize LLM client with comprehensive configuration.
        
        Args:
            primary_model: Primary model to use 
                (e.g., "openrouter/qwen-2.5-coder-32b-instruct" or alias "qwen-coder")
            fallback_models: List of fallback models in order of preference
            temperature: Sampling temperature (0.0-2.0)
            max_tokens: Maximum tokens in response
            max_retries: Number of retry attempts per model
            timeout: Request timeout in seconds
            enable_streaming: Whether to enable streaming responses
            require_json_mode: Require JSON mode capability from provider
        """
        config = get_config()
        
        # Resolve model aliases
        primary = primary_model or config.llm.primary
        self.primary_model = resolve_model_alias(primary)
        
        fallbacks = fallback_models or config.llm.fallback
        self.fallback_models = [resolve_model_alias(f) for f in fallbacks]
        
        self.temperature = temperature if temperature is not None else config.llm.temperature
        self.max_tokens = max_tokens
        self.max_retries = max_retries if max_retries > 0 else config.llm.max_retries
        self.timeout = timeout
        self.enable_streaming = enable_streaming
        self.require_json_mode = require_json_mode
        
        # Set up API keys from config
        self._setup_api_keys(config)
        
        # Track which provider we're currently using
        self._current_model: Optional[str] = None
        self._last_error: Optional[str] = None
        self._attempted_models: List[str] = []

    def _setup_api_keys(self, config) -> None:
        """
        Set up API keys for various providers.
        
        Args:
            config: Application configuration
        """
        api_keys = config.llm.api_keys
        
        for provider, key_env_var in api_keys.items():
            # Resolve environment variable if needed
            if key_env_var.startswith("${") and key_env_var.endswith("}"):
                env_var_name = key_env_var[2:-1]
                key_value = os.environ.get(env_var_name)
                if key_value:
                    self._set_provider_key(provider, key_value)
            else:
                # Direct key value
                self._set_provider_key(provider, key_env_var)

    def _set_provider_key(self, provider: str, key: str) -> None:
        """
        Set API key for a specific provider.
        
        Args:
            provider: Provider name (openai, anthropic, etc.)
            key: API key value
        """
        # Map provider names to litellm expected environment variables
        key_map = {
            "openai": "OPENAI_API_KEY",
            "anthropic": "ANTHROPIC_API_KEY",
            "groq": "GROQ_API_KEY",
            "deepseek": "DEEPSEEK_API_KEY",
            "openrouter": "OPENROUTER_API_KEY",
            "together_ai": "TOGETHER_AI_API_KEY",
            "fireworks_ai": "FIREWORKS_AI_API_KEY",
            "dashscope": "DASHSCOPE_API_KEY",
        }
        
        env_var = key_map.get(provider, f"{provider.upper()}_API_KEY")
        os.environ[env_var] = key
        logger.debug(f"Set API key for {provider}")

    def _get_all_models(self) -> List[str]:
        """
        Get complete list of models to try (primary + fallbacks).
        
        Filters models based on required capabilities if configured.
        
        Returns:
            List of model names in order of preference
        """
        models = [self.primary_model] if self.primary_model else []
        models.extend(self.fallback_models)
        
        # Filter out empty entries
        valid_models = [m for m in models if m]
        
        # If JSON mode is required, filter providers that support it
        if self.require_json_mode:
            filtered = []
            for model in valid_models:
                provider_info = get_provider_info(model)
                if provider_info and provider_info.supports_json_mode:
                    filtered.append(model)
                elif not provider_info:
                    # Unknown provider, include anyway
                    filtered.append(model)
            if filtered:
                valid_models = filtered
                logger.debug(f"Filtered models for JSON mode: {valid_models}")
        
        return valid_models

    def complete(
        self,
        prompt: Union[str, List[Dict[str, str]], List[Message]],
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        response_format: Optional[str] = None,
        **kwargs,
    ) -> LLMResponse:
        """
        Send a completion request to the LLM.
        
        Args:
            prompt: User prompt (string or list of messages)
            system_prompt: Optional system prompt to prepend
            temperature: Override default temperature
            max_tokens: Override default max tokens
            response_format: Expected format ("text" or "json")
            **kwargs: Additional arguments passed to litellm
            
        Returns:
            LLMResponse with content and metadata
            
        Raises:
            RuntimeError: If all providers fail
        """
        messages = self._build_messages(prompt, system_prompt)
        temp = temperature if temperature is not None else self.temperature
        tokens = max_tokens if max_tokens is not None else self.max_tokens
        
        # Build base parameters
        params = {
            "messages": messages,
            "temperature": temp,
            "max_tokens": tokens,
            "timeout": self.timeout,
            **kwargs,
        }
        
        # Add JSON format if requested
        if response_format == "json":
            params["response_format"] = {"type": "json_object"}
        
        # Try each model in order
        models_to_try = self._get_all_models()
        
        if not models_to_try:
            raise RuntimeError("No models configured. Check your config.yaml")
        
        last_error = None
        
        for i, model in enumerate(models_to_try):
            is_fallback = i > 0
            self._current_model = model
            self._attempted_models.append(model)
            
            try:
                response = self._try_completion(model, params)
                
                # Extract provider from model name
                provider = model.split("/")[0] if "/" in model else "unknown"
                
                return LLMResponse(
                    content=response.choices[0].message.content or "",
                    model=model,
                    provider=provider,
                    usage={
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens,
                    } if hasattr(response, "usage") and response.usage else {},
                    raw_response=response,
                    fallback_used=is_fallback,
                )
                
            except Exception as e:
                last_error = str(e)
                self._last_error = last_error
                
                # Log with appropriate level based on whether it's a fallback
                log_func = logger.warning if is_fallback else logger.info
                log_func(
                    f"Model {model} failed (attempt {i+1}/{len(models_to_try)}): {last_error}"
                )
                
                # Clear current model on failure
                self._current_model = None
        
        # All models failed
        raise RuntimeError(
            f"All LLM providers failed. Last error: {last_error}. "
            f"Tried models: {self._attempted_models}"
        )

    def _try_completion(self, model: str, params: Dict[str, Any]) -> Any:
        """
        Attempt completion with retry logic and exponential backoff.
        
        Args:
            model: Model name to use
            params: Parameters for litellm.completion
            
        Returns:
            Raw litellm response
            
        Raises:
            Exception: If all retries fail
        """
        import time
        
        for attempt in range(self.max_retries + 1):
            try:
                # Set the model in params
                params_with_model = {"model": model, **params}
                
                logger.debug(
                    f"Calling LLM: model={model}, attempt={attempt + 1}/{self.max_retries + 1}"
                )
                
                response = litellm_completion(**params_with_model)
                return response
                
            except RateLimitError as e:
                logger.warning(f"Rate limit hit for {model}, attempt {attempt + 1}")
                if attempt == self.max_retries:
                    raise
                # Exponential backoff for rate limits
                backoff_time = (2 ** attempt) * 0.5  # 0.5s, 1s, 2s, ...
                time.sleep(backoff_time)
                
            except Timeout as e:
                logger.warning(f"Timeout for {model}, attempt {attempt + 1}")
                if attempt == self.max_retries:
                    raise
                time.sleep(0.5 * (attempt + 1))
                    
            except APIConnectionError as e:
                logger.warning(f"Connection error for {model}, attempt {attempt + 1}")
                if attempt == self.max_retries:
                    raise
                time.sleep(0.5 * (attempt + 1))
            
            except AuthenticationError as e:
                # Auth errors shouldn't be retried with same credentials
                logger.error(f"Authentication failed for {model}: {e}")
                raise
                    
            except BadRequestError as e:
                # Bad request errors shouldn't be retried
                logger.error(f"Bad request for {model}: {e}")
                raise
                    
            except Exception as e:
                # For other errors, log and potentially retry
                logger.warning(f"Error with {model}: {type(e).__name__}: {e}, attempt {attempt + 1}")
                if attempt == self.max_retries:
                    raise
                time.sleep(0.5 * (attempt + 1))
        
        raise RuntimeError(f"Failed after {self.max_retries + 1} attempts")

    def _build_messages(
        self,
        prompt: Union[str, List[Dict[str, str]], List[Message]],
        system_prompt: Optional[str] = None,
    ) -> List[Dict[str, str]]:
        """
        Build messages list for litellm.
        
        Args:
            prompt: User prompt in various formats
            system_prompt: Optional system prompt
            
        Returns:
            List of message dictionaries
        """
        messages = []
        
        # Add system prompt first if provided
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        
        # Handle different input formats
        if isinstance(prompt, str):
            messages.append({"role": "user", "content": prompt})
        elif isinstance(prompt, list):
            for item in prompt:
                if isinstance(item, Message):
                    messages.append(item.to_dict())
                elif isinstance(item, dict):
                    messages.append(item)
                else:
                    raise ValueError(f"Invalid message type: {type(item)}")
        else:
            raise ValueError(f"Invalid prompt type: {type(prompt)}")
        
        return messages

    def complete_json(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Send a completion request expecting JSON response.
        
        Args:
            prompt: User prompt
            system_prompt: Optional system prompt
            **kwargs: Additional arguments for complete()
            
        Returns:
            Parsed JSON response as dictionary
            
        Raises:
            json.JSONDecodeError: If response is not valid JSON
            RuntimeError: If LLM call fails
        """
        response = self.complete(
            prompt=prompt,
            system_prompt=system_prompt,
            response_format="json",
            **kwargs,
        )
        
        return response.parse_json()

    def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: Optional[float] = None,
        **kwargs,
    ) -> LLMResponse:
        """
        Send a multi-turn chat request.
        
        Args:
            messages: List of conversation messages
            temperature: Override default temperature
            **kwargs: Additional arguments for complete()
            
        Returns:
            LLMResponse with assistant's reply
        """
        return self.complete(
            prompt=messages,
            temperature=temperature,
            **kwargs,
        )

    def get_current_model(self) -> Optional[str]:
        """Get the currently active model."""
        return self._current_model

    def get_last_error(self) -> Optional[str]:
        """Get the last error message."""
        return self._last_error
    
    def get_attempted_models(self) -> List[str]:
        """Get list of models that were attempted in the last request."""
        return self._attempted_models.copy()
    
    def clear_history(self) -> None:
        """Clear tracking history for a fresh start."""
        self._attempted_models = []
        self._last_error = None


# Convenience function for quick usage
def quick_complete(
    prompt: str,
    system_prompt: Optional[str] = None,
    model: Optional[str] = None,
    temperature: float = 0.3,
    max_tokens: int = 4096,
    **kwargs,
) -> LLMResponse:
    """
    Quick one-line LLM completion without explicit client initialization.
    
    Args:
        prompt: User prompt
        system_prompt: Optional system prompt
        model: Model to use (alias or full name)
        temperature: Sampling temperature
        max_tokens: Maximum tokens in response
        **kwargs: Additional arguments for LLMClient
    
    Returns:
        LLMResponse with content
    
    Example:
        >>> from miniagent.llm import quick_complete
        >>> response = quick_complete("What is Python?", model="qwen-coder")
        >>> print(response.content)
    """
    client = LLMClient(
        primary_model=model,
        temperature=temperature,
        max_tokens=max_tokens,
        **kwargs
    )
    return client.complete(prompt, system_prompt)


def create_client_for_capability(
    capability: ProviderCapability,
    require_free: bool = False,
    **kwargs,
) -> LLMClient:
    """
    Create an LLMClient optimized for a specific capability.
    
    Args:
        capability: Required provider capability
        require_free: Only use free tier providers
        **kwargs: Additional arguments for LLMClient
    
    Returns:
        Configured LLMClient instance
    
    Example:
        >>> from miniagent.llm import create_client_for_capability, ProviderCapability
        >>> client = create_client_for_capability(ProviderCapability.FAST_INFERENCE)
        >>> response = client.complete("Quick task")
    """
    best_provider = select_best_provider(
        required_capabilities=[capability],
        require_free=require_free,
    )
    
    if not best_provider:
        raise ValueError(f"No provider found with capability: {capability}")
    
    # Set as primary model
    kwargs["primary_model"] = best_provider
    
    return LLMClient(**kwargs)
