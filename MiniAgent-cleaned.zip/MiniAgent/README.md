# MiniAgent
Miniagent — kerangka kerja agentic AI yang ringan dan modular untuk membangun autonomous agent, mendukung tool-use, memory, dan multi-step reasoning.
